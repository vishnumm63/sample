import React, { Component } from 'react'

export default class GetUser extends Component {
    render() {
        return (
            <div>
                <h1>Welcome to Axios</h1>
            </div>
        )
    }
}
