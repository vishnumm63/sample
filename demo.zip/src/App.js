import logo from './logo.svg';
import './App.css';
import GetUser from './components/GetUser';

function App() {
  return (
    <GetUser/>
  );
}

export default App;
